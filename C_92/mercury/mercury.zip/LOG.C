,remoteNote.c was moved to f1.c
,remoteNote.old.c was moved to f2.c
remoteNote.c was moved to f3.c
remoteNote.old.c was moved to f4.c
tstr.c was moved to f5.c
