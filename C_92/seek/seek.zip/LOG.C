filter.c was moved to f1.c
grade.c was moved to f2.c
seekcreate.c was moved to f3.c
seekmain.c was moved to f4.c
seekxview.c was moved to f5.c
sort.c was moved to f6.c
twtsp90.c was moved to f7.c
